/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.com.elektra.sistemas.pdv.service;

import java.util.ArrayList;
import java.util.List;
import mx.com.elektra.sistemas.pdv.model.Articulo;
import mx.com.elektra.sistemas.pdv.model.Persona;
import mx.com.elektra.sistemas.pdv.model.Sucursal;

/**
 *
 * @author ramonrobles
 */
public class SucursalService {

    Sucursal suc;
    Persona per;

    public SucursalService(Sucursal s, Persona p) {
        this.suc = s;
        this.per = p;
    }
    
    public void inicializaInventario(){
        Articulo a1=new Articulo(1, "TV", "Pantalla SONY 48\"", 7.800, 5,"1010232987653");
        Articulo a2=new Articulo(2, "TV", "Pantalla SONY 50\"", 10.000, 10,"1010232987653");
        Articulo a3=new Articulo(3, "Telefono Celular", "Iphone X 256Gb", 29000.00, 0,"1010232987653");
        Articulo a4=new Articulo(4, "Telefono Celular", "Iphone 8 4.7\" Color Plata 64Gb ", 16499.00, 0,"99988765625");
        Articulo a5=new Articulo(5, "Telefono Celular", "Iphone 8 4.7\" Color Plata 256Gb ", 19999.00, 0,"999887657364");
        Articulo a6=new Articulo(6, "Telefono Celular", "Iphone 8 Plus 5.5\" Color Plata 64Gb ", 18999.00, 0,"77658765425");
        Articulo a7=new Articulo(7, "Telefono Celular", "Iphone 8 Plus 5.5\" Color Plata 256Gb ", 22499.00, 0,"77698765425");
    
        List<Articulo> articulos=new ArrayList<Articulo>();
        articulos.add(a1);
        articulos.add(a2);
        articulos.add(a3);
        articulos.add(a4);
        articulos.add(a5);
        articulos.add(a6);
        articulos.add(a7);
        this.suc.setArticulos(articulos);
    
    }

    public void recibePersona() {
        System.out.println("***** Hola "+per.getNombre()+", Bienvenido a " + this.suc.getNombre() + " *****");
        System.out.println("Actualmente contamos con los siguientes productos (Los precios se muestran sin IVA):");
        System.out.println("");
        for (Articulo art : this.suc.getArticulos()) {
            System.out.println(art);
        }
      
    }

}
