package mx.com.elektra.sistemas.pdv.model;

public class Cliente extends Persona {
    
    private int idCliente;
    private String rfc;
    private String telefono;
    private String correo;
    private String direccionFacturacion;
    
    public Cliente(){
        
    }
    
    protected int getIdCliente() {
        return idCliente;
    }

    protected void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    protected String getRfc() {
        return rfc;
    }

    protected void setRfc(String rfc) {
        this.rfc = rfc;
    }

    protected String getTelefono() {
        return telefono;
    }

    protected void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    protected String getCorreo() {
        return correo;
    }

    protected void setCorreo(String correo) {
        this.correo = correo;
    }

    protected String getDireccionFacturacion() {
        return direccionFacturacion;
    }

    protected void setDireccionFacturacion(String direccionFacturacion) {
        this.direccionFacturacion = direccionFacturacion;
    }
    
}
