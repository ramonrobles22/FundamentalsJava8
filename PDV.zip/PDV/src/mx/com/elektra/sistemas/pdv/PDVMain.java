package mx.com.elektra.sistemas.pdv;

import mx.com.elektra.sistemas.pdv.model.Persona;
import mx.com.elektra.sistemas.pdv.model.Sucursal;
import mx.com.elektra.sistemas.pdv.service.SucursalService;

public class PDVMain {

    public static void main(String[] args) {
        // Inicializo los Objetos
        Sucursal suc=new Sucursal(1,"Sucursal Ekt Corporativa","Av. Insurgentes Sur 1536","555-123-234");
        Persona sujeto1=new Persona("Ramón", "Robles", "García", "1988-08-31", 'M');
        
        SucursalService ss=new SucursalService(suc,sujeto1);
        ss.inicializaInventario();
        ss.recibePersona();
        
        //MOSTRAR PRODUCTOS/ARTICULOS
        //AGRAGAR ARTICULOS CARRITO
            //MOSTRAR ARTICULOS
        //ELIMINAR ARTICULOS
            //MOSTRAR CARRITO
        //PAGAR (GENERA TICKET Y RECUPERAR EL TICKET ID)
            //CALCULO DEL TOTAL
            //IMPUESTOS IVA(16%)
            //DESCUENTOS (ARTICULO,CANTIDAD,MONTO)
        //BUSCAR/DESPLEGAR TICKET
            //BUSCAR CLIENTE(RFC)
                //CREAR CLIENTE
        //GENERAR FACTURA (REGRESAR FACTURA IMPRESA)
        
    }

}
