package mx.com.elektra.sistemas.pdv.model;

import java.text.DecimalFormat;
import java.text.NumberFormat;

public class Articulo {

    protected int idArticulo;
    protected String nombre;
    protected String descripcion;
    protected double precio;
    protected double descuento;
    protected String codBarras;

    public Articulo(int idArticulo, String nombre, String descripcion, double precio, double descuento, String codBarras) {
        this.idArticulo = idArticulo;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
        this.descuento = descuento;
        this.codBarras = codBarras;
    }

    public int getIdArticulo() {
        return idArticulo;
    }

    public void setIdArticulo(int idArticulo) {
        this.idArticulo = idArticulo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public double getDescuento() {
        return descuento;
    }

    public void setDescuento(double descuento) {
        this.descuento = descuento;
    }

    public String getCodBarras() {
        return codBarras;
    }

    public void setCodBarras(String codBarras) {
        this.codBarras = codBarras;
    }

    @Override
    public String toString() {
        return "-Sku=" + idArticulo + ":" + nombre + "," + descripcion + ", Precio:" + String.format("$%,.2f", precio);
    }
    

}
